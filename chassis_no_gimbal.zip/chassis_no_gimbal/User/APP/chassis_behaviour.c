#include "chassis_behaviour.h"
#include "ChassisL_Task.h"

void FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(FSM_t *FSM);

/**
 * @brief ѡ�����ģʽ
 *
 * @param chassis ����ȫ������ָ��
 * @return
 */
void chassis_mode_set(chassis_move_t *chassis)
{
    if (chassis == NULL) {return;}
    if (switch_is_up(chassis->chassis_RC->RC.sw[3]))
    {
        chassis_mode = CHASSIS_ZERO_FORCE;
    }
    else
    {
        FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(&chassis->FSM);
        if (switch_is_mid(chassis->chassis_RC->RC.sw[3]) && switch_is_up(chassis->chassis_RC->RC.sw[1]))
        {
            chassis_mode = CHASSIS_CHECK_IN;
        }
        else if (switch_is_mid(chassis->chassis_RC->RC.sw[3]) && switch_is_down(chassis->chassis_RC->RC.sw[1]))
        {
            chassis_mode = CHASSIS_INFANTRY_FOLLOW_GIMBAL_YAW;
        }
    }

}

/**
 * @brief ���õ���Ŀ��ֵ
 * @param
 * @return
 */
void chassis_set_control(chassis_move_t *chassis)
{
    if (chassis == NULL)  {return;}
    if (chassis_mode == CHASSIS_ZERO_FORCE)
    {
        chassis_move.Target_Omega = 0.0f;
        chassis_move.Target_Roll = 0.0f;
        chassis_move.Target_Theta = 0.0f;
        chassis->Target_X = chassis->X_filter;

    }
    else if (chassis_mode == CHASSIS_CHECK_IN)
    {
        float vx_channel = 0, vy_channel = 0, vz_channel = 0;
        vx_channel = -chassis->chassis_RC->RC.ch[2];
        // ң����ҡ�˿��ܴ���ƫ�������Χ�ڵ���������
        vx_channel = Float_Math_Abs(vx_channel) > DR16_Rocker_Dead_Zone ? vx_channel : 0.0f;
        // �����ٶ�
        chassis_move.Target_Velocity_X = vx_channel * MAX_Velocity_X;
        // ����ƫ�����ٶ�
        chassis_move.Target_Omega = 0.0f;
        // ����ƫ��Ŀ��
        //chassis_move.Target_Yaw = vy_channel;
        // ���ú��Ŀ��
        chassis_move.Target_Roll = 0.0f;
        // ���� theta ���Ŀ��
        chassis_move.Target_Theta = 0.0f;

        chassis_move.Target_Leg_l = vz_channel * RC_to_Chassis_Leg_Gain;
        chassis_move.Target_Leg_r = vz_channel * RC_to_Chassis_Leg_Gain;
    }
    else if (chassis_mode == CHASSIS_INFANTRY_FOLLOW_GIMBAL_YAW)
    {
        float vx_channel = 0, vy_channel = 0, vz_channel = 0;
        vx_channel = chassis->chassis_RC->RC.ch[3];
        //vy_channel = chassis->chassis_RC->RC.ch[1];
        vz_channel = chassis->chassis_RC->RC.ch[1];
        // ң����ҡ�˿��ܴ���ƫ�������Χ�ڵ���������
        vx_channel = Float_Math_Abs(vx_channel) > DR16_Rocker_Dead_Zone ? vx_channel : 0.0f;
        vy_channel = Float_Math_Abs(vy_channel) > DR16_Rocker_Dead_Zone ? vy_channel : 0.0f;
        vz_channel = Float_Math_Abs(vz_channel) > DR16_Rocker_Dead_Zone ? vz_channel : 0.0f;

        // �����ٶ�
        chassis_move.Target_Velocity_X = vx_channel * MAX_Velocity_X;
        // ����ƫ�����ٶ�
        // chassis_move.Target_Omega = -chassis_move.PID_follow_yaw.Out;
        chassis_move.Target_Omega = 0.0f;
        // ����ƫ��Ŀ��
        //chassis_move.Target_Velocity_Y = vy_channel * MAX_Velocity_Y;
        // ���ú��Ŀ��
        chassis_move.Target_Roll = 0.0f;
        // ���� theta ���Ŀ��
        chassis_move.Target_Theta = 0.04f;

        chassis_move.Target_Leg_l = vz_channel * RC_to_Chassis_Leg_Gain;
        chassis_move.Target_Leg_r = vz_channel * RC_to_Chassis_Leg_Gain;
    }

}

void FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(FSM_t *FSM)
{
    FSM->Status[FSM->Now_Status].Count_Time++;

    const float theta_l = chassis_move.left_leg.theta;
    const float theta_r = chassis_move.right_leg.theta;
    const float L0_l    = chassis_move.left_leg.L0;
    const float L0_r    = chassis_move.right_leg.L0;
    const float pitch   = chassis_move.pitch;
    // �Լ����ű�д״̬ת�ƺ���
    switch (FSM->Now_Status)
    {
    case NORMAL:
        if (theta_l >= 0.8f || theta_r >= 0.8f)
        {
            FSM_Set_Status(FSM, OVER_TURN);
        }
        break;
    case OVER_TURN:
        FSM_Set_Status(FSM, OVER_TURNING);
        break;
    case OVER_TURNING:
        if (Float_Math_Abs(pitch) <= PI/4.0f && theta_l <= 0.2f && theta_l >= -0.8f && theta_r <= 0.2f && theta_r >= -0.8f)
        {
            FSM_Set_Status(FSM, NORMAL);
        }
        break;
    }
}

void chassis_control_left_leg(float target)
{
    if(target != 0.0f)
    {
        // LQR���ؼ���
        chassis_move.T_wl = 0.0f;
        chassis_move.left_leg.Tp = (chassis_move.left_leg.d_theta - target) * Fitting_K[2][5];
        chassis_move.left_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.left_leg);
    }
    else
    {
        chassis_move.T_wl = 0.0f;
        chassis_move.left_leg.Tp = 0.0f;
        chassis_move.left_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.left_leg);
    }
}
void chassis_control_right_leg(float target)
{
    if(target != 0.0f)
    {
        // LQR���ؼ���
        chassis_move.T_wr = 0.0f;
        chassis_move.right_leg.Tp = (chassis_move.right_leg.d_theta - target) * Fitting_K[2][5];
        chassis_move.right_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.right_leg);
    }
    else
    {
        chassis_move.T_wr = 0.0f;
        chassis_move.right_leg.Tp = 0.0f;
        chassis_move.right_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.right_leg);
    }
}

void chassis_over_turn_mod(chassis_move_t *chassis)
{
    const float theta_l = chassis->left_leg.theta;
    const float theta_r = chassis->right_leg.theta;

    chassis->Target_Velocity_X = 0.0f;
    chassis->Target_X          = 0.0f;
    chassis->Target_Omega      = 0.0f;
    chassis->Target_Roll       = 0.0f;
    chassis->Target_Theta      = 0.0f;

    if (theta_l < -0.9f || theta_l > 1.4f)          { chassis_control_left_leg(-5.0f); }
    else                                            { chassis_control_left_leg(0.0f);  }

    if (theta_r < -0.9f || theta_r > 1.4f)          { chassis_control_right_leg(-5.0f); }
    else                                            { chassis_control_right_leg(0.0f);  }
}