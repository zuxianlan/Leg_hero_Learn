/**
  ******************************************************************************
  * @file           : Transmission_link.c
  * @author         : Chen Haoran
  * @brief          : None
  * @attention      : None
  * @date           : 2026/3/10
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "Transmission_link.h"
/* Define --------------------------------------------------------------------*/

/* Enum ----------------------------------------------------------------------*/

/* Variable && Struct --------------------------------------------------------*/
uint8_t SOF = 0;
uint8_t control_rx_buf[2][RX_Control_User_add]; //ͼ����·˫������
uint8_t user_rx_buf[2][Edit_User_add]; //�Զ���˫������
uint8_t Transmission_rx_buf[REFREE_RX_LEN]; //ͼ����·��������
uint8_t Referee[REFREE_RX_LEN]; //����ϵͳ��������
uint8_t referee_tx_buffer[128];
uint8_t refree_rx_buf[REFREE_RX_LEN];
VT13_RC_ctrl_t VT13_rc_ctrl;
uint8_t UI_Change_Flag[10][10] = {0};
Referee_Data_Interaction_Graphic_Config_t Graphic_Config[10][10];

/* Function Declaration ------------------------------------------------------*/
void Referee_Data_Process(uint16_t Length);

void Tranmission_Data_Process(uint16_t Length);

/* Function ------------------------------------------------------------------*/

void process_key(Key_Pressed *key)
{
    int cur = key->key_state;
    int prev = key->prev_state;

    if (cur == 1)
    {
        if (prev == 0)
        {
            key->press_counter = 1;
            key->long_triggered = false;
        }
        else
        {
            key->press_counter++;
            if (key->press_counter >= LONG_PRESS_THRESHOLD && !key->long_triggered)
            {
                key->long_toggle_state = !key->long_toggle_state;
                key->long_triggered = true;
            }
        }
    }
    else
    {
        if (prev == 1)
        {
            if (!key->long_triggered)
            {
                key->short_toggle_state = !key->short_toggle_state;
            }
            key->press_counter = 0;
        }
    }

    key->prev_state = cur;

    // key->short_toggle_state = key->key_state;
    // key->long_toggle_state = key->key_state;
}

//����ϵͳ��غ���
void USER_USART1_RxHandler(UART_HandleTypeDef *huart, uint16_t Size)
{
    // ������·����
    Referee_Data_Process(Size);

    // ͼ����·ͼ��ң��������
    // Tranmission_Data_Process(Size);
}

void Transmission_Init(void) //����ϵͳ��ͼ����·���ڻ�������DMA����
{
    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, refree_rx_buf, REFREE_RX_LEN); //����ϵͳ��������
    // HAL_UARTEx_ReceiveToIdle_DMA(&huart1, Transmission_rx_buf, REFREE_RX_LEN);  //ͼ����·��������
}

uint8_t Verify_CRC_8(uint8_t *Message, uint32_t Length)
{
    uint8_t index;
    uint8_t check = 0xff;

    if (Message == NULL)
    {
        return (check);
    }

    while (Length--)
    {
        index = *Message;
        Message++;
        check = crc_8_table[check ^ index];
    }
    return (check);
}

uint16_t Verify_CRC_16(uint8_t *Message, uint32_t Length)
{
    uint8_t index;
    uint16_t check = 0xffff;

    if (Message == NULL)
    {
        return (check);
    }

    while (Length--)
    {
        index = *Message;
        Message++;
        check = ((uint16_t) (check) >> 8) ^ crc_16_table[((uint16_t) (check) ^ (uint16_t) (index)) & 0xff];
    }
    return (check);
}

void Referee_Data_Process(uint16_t Length)
{
    // ���ݴ�������
    Referee_UART_Data_t *tmp_buffer;

    for (int i = 0; i < Length;)
    {
        tmp_buffer = (Referee_UART_Data_t *) &refree_rx_buf[i];

        // δͨ��ͷУ��
        if (tmp_buffer->Frame_Header != 0xA5)
        {
            i++;
            continue;
        }
        // δͨ��CRC8У��, ˳һλ�����ж�
        if (Verify_CRC_8((uint8_t *) tmp_buffer, 4) != tmp_buffer->CRC_8)
        {
            i++;
            continue;
        }
        // δͨ��CRC16У��, �����ǰ�������ж�
        if (Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length) != *(uint16_t *) (
                (uint32_t) tmp_buffer + 7 + tmp_buffer->Data_Length))
        {
            i += 9 + tmp_buffer->Data_Length;
            continue;
        }
        // ͨ��У�鵫֡������
        if (i + 7 + tmp_buffer->Data_Length + 2 > Length)
        {
            break;
        }

        switch (tmp_buffer->Referee_Command_ID)
        {
        case Referee_Command_ID_GAME_STATUS:
        {
            memcpy(&game_state, tmp_buffer->Data, sizeof(ext_game_state_t));
        }
        break;
        case Referee_Command_ID_GAME_RESULT:
        {
            memcpy(&game_result, tmp_buffer->Data, sizeof(ext_game_result_t));
        }
        break;
        case Referee_Command_ID_GAME_ROBOT_HP:
        {
            memcpy(&game_robot_HP, tmp_buffer->Data, sizeof(ext_game_robot_HP_t));
        }
        break;

        case Referee_Command_ID_EVENT_SELF_DATA:
        {
            memcpy(&event_data, tmp_buffer->Data, sizeof(ext_event_data_t));
        }
        break;
        case Referee_Command_ID_EVENT_SELF_REFEREE_WARNING:
        {
            memcpy(&referee_warning, tmp_buffer->Data, sizeof(ext_referee_warning_t));
        }
        break;
        case Referee_Command_ID_EVENT_SELF_DART_STATUS:
        {
            memcpy(&dart_info, tmp_buffer->Data, sizeof(ext_dart_info_t));
        }
        break;
        case Referee_Command_ID_ROBOT_STATUS:
        {
            memcpy(&robot_state, tmp_buffer->Data, sizeof(ext_robot_state_t));
        }
        break;
        case Referee_Command_ID_ROBOT_POWER_HEAT:
        {
            memcpy(&power_heat_data, tmp_buffer->Data, sizeof(ext_power_heat_data_t));
        }
        break;
        case Referee_Command_ID_ROBOT_POSITION:
        {
            memcpy(&robot_pos, tmp_buffer->Data, sizeof(ext_robot_pos_t));
        }
        break;
        case Referee_Command_ID_ROBOT_BUFF:
        {
            memcpy(&buff, tmp_buffer->Data, sizeof(ext_buff_t));
        }
        break;
        case Referee_Command_ID_ROBOT_DAMAGE:
        {
            memcpy(&hurt_data, tmp_buffer->Data, sizeof(ext_hurt_data_t));
        }
        break;
        case Referee_Command_ID_ROBOT_BOOSTER:
        {
            memcpy(&shoot_data, tmp_buffer->Data, sizeof(ext_shoot_data_t));
        }
        break;
        case Referee_Command_ID_ROBOT_REMAINING_AMMO:
        {
            memcpy(&projectile_allowance, tmp_buffer->Data, sizeof(ext_projectile_allowance_t));
        }
        break;
        case Referee_Command_ID_ROBOT_RFID:
        {
            memcpy(&rfid_status, tmp_buffer->Data, sizeof(ext_rfid_status_t));
        }
        break;
        case Referee_Command_ID_ROBOT_SENTRY_LOCATION:
        {
            memcpy(&groundRobotPosition, tmp_buffer->Data, sizeof(ground_robot_position_t));
        }
        break;
        case Referee_Command_ID_ROBOT_SENTRY_DECISION:
        {
            memcpy(&sentryInfo, tmp_buffer->Data, sizeof(sentry_info_t));
        }
        break;
        case Referee_Command_ID_INTERACTION:
        {
            memcpy(&robotInteractionData, tmp_buffer->Data, sizeof(robot_interaction_data_t));
        }
        break;
        case ROBOT_COMMAND_ID:
        {
            memcpy(&robot_command_t, tmp_buffer->Data, sizeof(ext_robot_command_t));
        }
        break;
        default:
        {
            break;
        }
        }

        //������ֱ������
        i += 7 + tmp_buffer->Data_Length + 2;
    }
}

void Sentry_Decision_Transmit(sentry_cmd_t *sentry_info, uint8_t *tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) tx_buffer;

    tmp_buffer->Frame_Header = 0xa5;
    tmp_buffer->Data_Length = sizeof(sentry_cmd_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = 0x0301;

    sentry_cmd_t *tmp_data = (sentry_cmd_t *) tmp_buffer->Data;
    tmp_data->Header = 0x0120;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = Referee_Data_Robots_Server;

    tmp_data->Confirm_Respawn_Status = sentry_info->Confirm_Respawn_Status;
    tmp_data->Confirm_Exchange_Respawn_Status = sentry_info->Confirm_Exchange_Respawn_Status;
    tmp_data->Request_Exchange_Ammo_Number = sentry_info->Request_Exchange_Ammo_Number;
    tmp_data->Request_Exchange_Ammo_Time = sentry_info->Request_Exchange_Ammo_Time;
    tmp_data->Request_Exchange_HP_Time = sentry_info->Request_Exchange_HP_Time;

    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(sentry_cmd_t), 80);
    SOF++;
}

//ͼ����·���ݴ���
void Tranmission_Data_Process(uint16_t Length)
{
    // ���ݴ�������
    Struct_Transmission_UART_Data *tmp_buffer;

    // for (int i = 0; i < Length;)
    // {
    //     tmp_buffer = (Struct_Transmission_UART_Data *) &Transmission_rx_buf[i];
    //     // ���֡ͷ0xA9
    //     if (Transmission_rx_buf[i] == 0xA9 && (i + 1 < Length))
    //     {
    //         // ���ڶ��ֽ��Ƿ�Ϊ0x53
    //         if (Transmission_rx_buf[i + 1] == 0x53)
    //         {
    //             // ȷ�����ݳ����㹻
    //             if (i + 21 > Length)
    //             {
    //                 break; // ���ݲ��㣬�ȴ�����
    //             }
    //
    //             memcpy(&VT13_rc_ctrl, &Transmission_rx_buf[i], 21);
    //             i += 21;
    //             continue;
    //         }
    //         else
    //         {
    //             i++;
    //             continue;
    //         }
    //     }
    // }


    for (int i = 0; i < Length;)
    {
        // ѭ����ȡ����

        // ��֤��һ����ͷ
        if (Transmission_rx_buf[i] == 0xA9 && (i + 1 < Length))
        {
            // ��֤�ڶ�����ͷ
            if (Transmission_rx_buf[i + 1] == 0x53)
            {
                // ȷ�����ݳ����㹻
                if (i + 21 > Length)
                {
                    break; //���ݲ���ȴ�����
                }

                // CRC16У��
                if (verify_CRC16_check_sum(&Transmission_rx_buf[i], 21))
                {
                    memcpy(&VT13_rc_ctrl, &Transmission_rx_buf[i], 21);
                }
            }
        }
        else
        {
            i++;
            continue;
        }
    }
}

/**
 * @brief �趨����ϵͳUI���
 *
 */
void Set_Referee_UI_Change_Flag_Clear()
{
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            UI_Change_Flag[i][j] = 0;
        }
    }
}

/**
 * @brief �趨����ϵͳUI���
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Clear(uint8_t Layer_Num, uint8_t Graphic_Num)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;

    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_DELETE;

    UI_Change_Flag[Layer_Num][Graphic_Num] = 0;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}


/**
 * @brief �趨����ϵͳUIֱ��
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Start_X ���x
 * @param Start_Y ���y
 * @param End_X �յ�x
 * @param End_Y �յ�y
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Line(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                               Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                               uint32_t Line_Width, uint32_t Start_X, uint32_t Start_Y,
                                                               uint32_t End_X, uint32_t End_Y)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_LINE;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Start_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Start_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_D = End_X;
    Graphic_Config[Layer_Num][Graphic_Num].Details_E = End_Y;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUI����
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Start_X ���x
 * @param Start_Y ���y
 * @param End_X �յ�x
 * @param End_Y �յ�y
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Rectangle(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                                    Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                                    uint32_t Line_Width, uint32_t Start_X,
                                                                    uint32_t Start_Y, uint32_t End_X, uint32_t End_Y)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_RECTANGLE;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Start_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Start_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_D = End_X;
    Graphic_Config[Layer_Num][Graphic_Num].Details_E = End_Y;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUIԲ��
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Center_X Բ��x
 * @param Center_Y Բ��y
 * @param Radius �뾶
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Circle(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                                 Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                                 uint32_t Line_Width, uint32_t Center_X,
                                                                 uint32_t Center_Y, uint32_t Radius)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_CIRCLE;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Center_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Center_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_C = Radius;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUI��Բ��
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Center_X Բ��x
 * @param Center_Y Բ��y
 * @param Length_X x���᳤��
 * @param Length_Y y���᳤��
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Oval(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                               Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                               uint32_t Line_Width, uint32_t Center_X,
                                                               uint32_t Center_Y, uint32_t Length_X, uint32_t Length_Y)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_OVAL;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Center_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Center_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_D = Length_X;
    Graphic_Config[Layer_Num][Graphic_Num].Details_E = Length_Y;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUIԲ����
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Center_X Բ��x
 * @param Center_Y Բ��y
 * @param Angle_Start ��ʼ�Ƕ�
 * @param Angle_End ��ֹ�Ƕ�
 * @param Length_X x���᳤��
 * @param Length_Y y���᳤��
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Arc(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                              Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                              uint32_t Line_Width, uint32_t Center_X, uint32_t Center_Y,
                                                              uint32_t Angle_Start, uint32_t Angle_End,
                                                              uint32_t Length_X, uint32_t Length_Y)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_ARC;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Center_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Center_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_A = Angle_Start;
    Graphic_Config[Layer_Num][Graphic_Num].Details_B = Angle_End;
    Graphic_Config[Layer_Num][Graphic_Num].Details_D = Length_X;
    Graphic_Config[Layer_Num][Graphic_Num].Details_E = Length_Y;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUI������
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Start_X ���x
 * @param Start_Y ���y
 * @param Font_Width �����С
 * @param Float ��ֵ
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Float(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                                Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                                uint32_t Line_Width, uint32_t Start_X, uint32_t Start_Y,
                                                                uint32_t Font_Width, float Float)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_FLOAT;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Start_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Start_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_A = Font_Width;
    int32_t *tmp_pointer = (int32_t *) ((uint32_t) &Graphic_Config[Layer_Num][Graphic_Num] + 11);
    *tmp_pointer = (int32_t) (Float * 1000.0f);

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUI������
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Start_X ���x
 * @param Start_Y ���y
 * @param Font_Width �����С
 * @param Integer ��ֵ
 * @return ��Ӧͼ��ָ��
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_Integer(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                                  Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                                  uint32_t Line_Width, uint32_t Start_X,
                                                                  uint32_t Start_Y, uint32_t Font_Width,
                                                                  int32_t Integer)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_INTEGER;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Start_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Start_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_A = Font_Width;
    int32_t *tmp_pointer = (int32_t *) ((uint32_t) &Graphic_Config[Layer_Num][Graphic_Num] + 11);
    *tmp_pointer = (int32_t) (Integer);

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

/**
 * @brief �趨����ϵͳUI�ַ���
 *
 * @param Layer_Num ͼ����, 0~9
 * @param Graphic_Num ͼ�α��, 0~9
 * @param Color ͼ����ɫ
 * @param Line_Width �߿�
 * @param Start_X ���x
 * @param Start_Y ���y
 * @param Font_Width �����С
 * @param String_Length �ַ�������
 * @return
 */
Referee_Data_Interaction_Graphic_Config_t *Set_Referee_UI_String(uint8_t Layer_Num, uint8_t Graphic_Num,
                                                                 Enum_Referee_Data_Interaction_Graphic_Color Color,
                                                                 uint32_t Line_Width, uint32_t Start_X,
                                                                 uint32_t Start_Y, uint32_t Font_Width,
                                                                 uint32_t String_Length)
{
    Graphic_Config[Layer_Num][Graphic_Num].Index[0] = '0';
    Graphic_Config[Layer_Num][Graphic_Num].Index[1] = '0' + Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Index[2] = '0' + Graphic_Num;

    if (UI_Change_Flag[Layer_Num][Graphic_Num] == 0)
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_ADD;
        UI_Change_Flag[Layer_Num][Graphic_Num] = 1;
    }
    else
    {
        Graphic_Config[Layer_Num][Graphic_Num].Operation_Enum = Referee_Data_Interaction_Graphic_Operation_CHANGE;
    }

    Graphic_Config[Layer_Num][Graphic_Num].Type_Enum = Referee_Data_Interaction_Graphic_Type_STRING;
    Graphic_Config[Layer_Num][Graphic_Num].Layer_Num = Layer_Num;
    Graphic_Config[Layer_Num][Graphic_Num].Color_Enum = Color;
    Graphic_Config[Layer_Num][Graphic_Num].Line_Width = Line_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Start_X = Start_X;
    Graphic_Config[Layer_Num][Graphic_Num].Start_Y = Start_Y;
    Graphic_Config[Layer_Num][Graphic_Num].Details_A = Font_Width;
    Graphic_Config[Layer_Num][Graphic_Num].Details_B = String_Length;

    return (&Graphic_Config[Layer_Num][Graphic_Num]);
}

void Referee_UART_Send_Interaction_UI_Graphic_1(Referee_Data_Interaction_Graphic_Config_t *Graphic_1,
                                                uint8_t *Tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) Tx_buffer;

    // ����ϵͳ֡ͷ
    tmp_buffer->Frame_Header = 0xA5;
    tmp_buffer->Data_Length = sizeof(Referee_Tx_Data_Interaction_Graphic_1_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = Referee_Command_ID_INTERACTION;

    // ����֡ͷ
    Referee_Tx_Data_Interaction_Graphic_1_t *tmp_data = (Referee_Tx_Data_Interaction_Graphic_1_t *) tmp_buffer->Data;
    tmp_data->Header = Referee_Interaction_Command_ID_UI_GRAPHIC_1;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = (Enum_Referee_Data_Robots_Client_ID) ((int) (robot_state.robot_id) + 0x100);

    // UI��һ��ͼ��֡����
    tmp_data->Graphic[0] = *Graphic_1;
    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(Referee_Tx_Data_Interaction_Graphic_1_t), 100);

    SOF++;
}

void Referee_UART_Send_Interaction_UI_Graphic_2(Referee_Data_Interaction_Graphic_Config_t *Graphic_1,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_2,
                                                uint8_t *Tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) Tx_buffer;

    // ����ϵͳ֡ͷ
    tmp_buffer->Frame_Header = 0xA5;
    tmp_buffer->Data_Length = sizeof(Referee_Tx_Data_Interaction_Graphic_2_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = Referee_Command_ID_INTERACTION;

    // ����֡ͷ
    Referee_Tx_Data_Interaction_Graphic_2_t *tmp_data = (Referee_Tx_Data_Interaction_Graphic_2_t *) tmp_buffer->Data;
    tmp_data->Header = Referee_Interaction_Command_ID_UI_GRAPHIC_2;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = (Enum_Referee_Data_Robots_Client_ID) ((int) (robot_state.robot_id) + 0x100);

    // UI��һ��ͼ��֡����
    tmp_data->Graphic[0] = *Graphic_1;
    tmp_data->Graphic[1] = *Graphic_2;
    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(Referee_Tx_Data_Interaction_Graphic_2_t), 100);

    SOF++;
}

void Referee_UART_Send_Interaction_UI_Graphic_5(Referee_Data_Interaction_Graphic_Config_t *Graphic_1,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_2,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_3,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_4,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_5,
                                                uint8_t *Tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) Tx_buffer;

    // ����ϵͳ֡ͷ
    tmp_buffer->Frame_Header = 0xA5;
    tmp_buffer->Data_Length = sizeof(Referee_Tx_Data_Interaction_Graphic_5_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = Referee_Command_ID_INTERACTION;

    // ����֡ͷ
    Referee_Tx_Data_Interaction_Graphic_5_t *tmp_data = (Referee_Tx_Data_Interaction_Graphic_5_t *) tmp_buffer->Data;
    tmp_data->Header = Referee_Interaction_Command_ID_UI_GRAPHIC_5;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = (Enum_Referee_Data_Robots_Client_ID) ((int) (robot_state.robot_id) + 0x100);

    // UI��һ��ͼ��֡����
    tmp_data->Graphic[0] = *Graphic_1;
    tmp_data->Graphic[1] = *Graphic_2;
    tmp_data->Graphic[2] = *Graphic_3;
    tmp_data->Graphic[3] = *Graphic_4;
    tmp_data->Graphic[4] = *Graphic_5;
    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(Referee_Tx_Data_Interaction_Graphic_5_t), 100);

    SOF++;
}

void Referee_UART_Send_Interaction_UI_Graphic_7(Referee_Data_Interaction_Graphic_Config_t *Graphic_1,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_2,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_3,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_4,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_5,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_6,
                                                Referee_Data_Interaction_Graphic_Config_t *Graphic_7,
                                                uint8_t *Tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) Tx_buffer;

    // ����ϵͳ֡ͷ
    tmp_buffer->Frame_Header = 0xA5;
    tmp_buffer->Data_Length = sizeof(Referee_Tx_Data_Interaction_Graphic_7_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = Referee_Command_ID_INTERACTION;

    // ����֡ͷ
    Referee_Tx_Data_Interaction_Graphic_7_t *tmp_data = (Referee_Tx_Data_Interaction_Graphic_7_t *) tmp_buffer->Data;
    tmp_data->Header = Referee_Interaction_Command_ID_UI_GRAPHIC_7;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = (Enum_Referee_Data_Robots_Client_ID) ((int) (robot_state.robot_id) + 0x100);

    // UI��һ��ͼ��֡����
    tmp_data->Graphic[0] = *Graphic_1;
    tmp_data->Graphic[1] = *Graphic_2;
    tmp_data->Graphic[2] = *Graphic_3;
    tmp_data->Graphic[3] = *Graphic_4;
    tmp_data->Graphic[4] = *Graphic_5;
    tmp_data->Graphic[5] = *Graphic_6;
    tmp_data->Graphic[6] = *Graphic_7;
    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(Referee_Tx_Data_Interaction_Graphic_7_t), 100);

    SOF++;
}

void Referee_UART_Send_Interaction_UI_Graphic_String(Referee_Data_Interaction_Graphic_Config_t *Graphic_String,
                                                     const char *String_Content, uint8_t *Tx_buffer)
{
    Referee_UART_Data_t *tmp_buffer = (Referee_UART_Data_t *) Tx_buffer;

    // ����ϵͳ֡ͷ
    tmp_buffer->Frame_Header = 0xa5;
    tmp_buffer->Data_Length = sizeof(Referee_Tx_Data_Interaction_Graphic_String_t) - 2;
    tmp_buffer->Sequence = SOF;
    tmp_buffer->CRC_8 = Verify_CRC_8((uint8_t *) tmp_buffer, 4);
    tmp_buffer->Referee_Command_ID = Referee_Command_ID_INTERACTION;

    // ����֡ͷ
    Referee_Tx_Data_Interaction_Graphic_String_t *tmp_data = (Referee_Tx_Data_Interaction_Graphic_String_t *) tmp_buffer
            ->Data;
    tmp_data->Header = Referee_Interaction_Command_ID_UI_GRAPHIC_STRING;
    tmp_data->Sender = robot_state.robot_id;
    tmp_data->Receiver = (Enum_Referee_Data_Robots_Client_ID) ((int) (robot_state.robot_id) + 0x100);

    // UI���ַ���֡����
    tmp_data->Graphic_String = *Graphic_String;
    bzero(tmp_data->String, 30);
    strcpy((char *) tmp_data->String, String_Content);

    tmp_data->CRC_16 = Verify_CRC_16((uint8_t *) tmp_buffer, 7 + tmp_buffer->Data_Length);

    HAL_UART_Transmit(&huart1, (uint8_t *) tmp_buffer, 7 + sizeof(Referee_Tx_Data_Interaction_Graphic_String_t), 80);

    SOF++;
}

const VT13_RC_ctrl_t *get_VT13_rc_control_point(void)
{
    return &VT13_rc_ctrl;
}
