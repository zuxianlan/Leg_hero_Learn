#include "chassis_behaviour.h"
#include "ChassisL_Task.h"

void FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(FSM_t *FSM);

/**
 * @brief ѡ�����ģʽ
 *
 * @param chassis ����ȫ������ָ��
 * @return
 */
void chassis_mode_set(chassis_move_t *chassis)
{
    if (chassis == NULL) {return;}
    if (switch_is_up(chassis->chassis_RC->RC.sw[3]))
    {
        chassis_mode = CHASSIS_ZERO_FORCE;
    }
    else
    {
        FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(&chassis->FSM);
        if (switch_is_mid(chassis->chassis_RC->RC.sw[3]) && switch_is_up(chassis->chassis_RC->RC.sw[1]))
        {
            chassis_mode = CHASSIS_CHECK_IN;
        }
        else if (switch_is_mid(chassis->chassis_RC->RC.sw[3]) && switch_is_down(chassis->chassis_RC->RC.sw[1]))
        {
            chassis_mode = CHASSIS_INFANTRY_FOLLOW_GIMBAL_YAW;
        }
    }

}

/**
 * @brief ���õ���Ŀ��ֵ
 * @param
 * @return
 */
void chassis_set_control(chassis_move_t *chassis)
{
    if (chassis == NULL)  {return;}
    if (chassis_mode == CHASSIS_ZERO_FORCE)
    {
        chassis_move.Chassis_target.Target_Omega = 0.0f;
        chassis_move.Chassis_target.Target_Roll = 0.0f;
        chassis_move.Chassis_target.Target_Theta = 0.0f;
        chassis->Chassis_target.Target_X = chassis->Wheel_data.X_filter;

    }
    else if (chassis_mode == CHASSIS_CHECK_IN)
    {
        float vx_channel = 0, vy_channel = 0, vz_channel = 0;
        vx_channel = -chassis->chassis_RC->RC.ch[2];
        // ң����ҡ�˿��ܴ���ƫ�������Χ�ڵ���������
        vx_channel = Float_Math_Abs(vx_channel) > DR16_Rocker_Dead_Zone ? vx_channel : 0.0f;
        chassis_move.Chassis_target.Target_Velocity_X = vx_channel * MAX_Velocity_X;
        chassis_move.Chassis_target.Target_Omega = 0.0f;
        chassis_move.Chassis_target.Target_Roll = 0.0f;
        chassis_move.Chassis_target.Target_Theta = 0.0f;

        chassis_move.Chassis_target.Target_Leg_l = vz_channel * RC_to_Chassis_Leg_Gain;
        chassis_move.Chassis_target.Target_Leg_r = vz_channel * RC_to_Chassis_Leg_Gain;
    }
    else if (chassis_mode == CHASSIS_INFANTRY_FOLLOW_GIMBAL_YAW)
    {
        float vx_channel = 0, vy_channel = 0, vz_channel = 0;
        vx_channel = chassis->chassis_RC->RC.ch[2];
        //vy_channel = chassis->chassis_RC->RC.ch[1];
        vz_channel = chassis->chassis_RC->RC.ch[3];
        // ң����ҡ�˿��ܴ���ƫ�������Χ�ڵ���������
        vx_channel = Float_Math_Abs(vx_channel) > DR16_Rocker_Dead_Zone ? vx_channel : 0.0f;
        vy_channel = Float_Math_Abs(vy_channel) > DR16_Rocker_Dead_Zone ? vy_channel : 0.0f;
        vz_channel = Float_Math_Abs(vz_channel) > DR16_Rocker_Dead_Zone ? vz_channel : 0.0f;

        chassis_move.Chassis_target.Target_Velocity_X = vx_channel * MAX_Velocity_X;  // �����ٶ�
        chassis_move.Chassis_target.Target_Omega = -chassis->PID_follow_yaw.Out; // ����ƫ�����ٶ�
        chassis_move.Chassis_target.Target_Roll = 0.0f;
        chassis_move.Chassis_target.Target_Leg_l = vz_channel * RC_to_Chassis_Leg_Gain;
        chassis_move.Chassis_target.Target_Leg_r = vz_channel * RC_to_Chassis_Leg_Gain;
    }

}

void FSM_TIM_Calculate_PeriodElapsedCallback_Chassis(FSM_t *FSM)
{
    FSM->Status[FSM->Now_Status].Count_Time++;

    const float theta_l = chassis_move.left_leg.theta;
    const float theta_r = chassis_move.right_leg.theta;
    const float L0_l    = chassis_move.left_leg.L0;
    const float L0_r    = chassis_move.right_leg.L0;
    const float pitch   = chassis_move.pitch;
    // �Լ����ű�д״̬ת�ƺ���
    switch (FSM->Now_Status)
    {
    case NORMAL:
        if (theta_l > 0.9f || theta_r > 0.9f || theta_l < -0.9f || theta_r < -0.9f)
        {
            FSM_Set_Status(FSM, OVER_TURN);
        }
        break;
    case OVER_TURN:
        if (Float_Math_Abs(theta_l - theta_r) < 0.3f)
        {
            if (theta_l >= 0.7f || theta_r >= 0.7f)
            {
                FSM_Set_Status(FSM, OVER_TURNING);
            }
        }
        // else
        // {
        //     /* ˫��������һ�� �� 0.9 ����һ������ [-0.8, 0.4] */
        //     if ((theta_l >= 0.9f && theta_r <= 0.4f && theta_r >= -0.8f) ||
        //         (theta_r >= 0.9f && theta_l <= 0.4f && theta_l >= -0.8f))
        //     {
        //         FSM_Set_Status(FSM, OVER_TURNING);
        //     }
        // }
       break;
    case OVER_TURNING:
        if (Float_Math_Abs(pitch) <= PI/4.0f && theta_l <= 0.2f && theta_l >= -0.8f && theta_r <= 0.2f && theta_r >= -0.8f && L0_l < 0.2f && L0_r < 0.2f)
        {
            FSM_Set_Status(FSM, NORMAL);
        }
        break;

    default:
        break;
    }
}

void chassis_control_left_leg(float target)
{
    if(target != 0.0f)
    {
        // LQR���ؼ���
        chassis_move.T_wl = 0.0f;
        chassis_move.left_leg.Tp = (chassis_move.left_leg.d_theta - target) * Fitting_K[2][5];
        chassis_move.left_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.left_leg);
    }
    else
    {
        chassis_move.T_wl = 0.0f;
        chassis_move.left_leg.Tp = 0.0f;
        chassis_move.left_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.left_leg);
    }
}
void chassis_control_right_leg(float target)
{
    if(target != 0.0f)
    {
        // LQR���ؼ���
        chassis_move.T_wr = 0.0f;
        chassis_move.right_leg.Tp = (chassis_move.right_leg.d_theta - target) * Fitting_K[3][7];
        chassis_move.right_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.right_leg);
    }
    else
    {
        chassis_move.T_wr = 0.0f;
        chassis_move.right_leg.Tp = 0.0f;
        chassis_move.right_leg.F0 = 0.0f;
        VMC_Calc_2(&chassis_move.right_leg);
    }
}

void chassis_over_turn_mod(chassis_move_t *chassis)
{
    chassis->Chassis_target.Target_Velocity_X = 0.0f;
    chassis->Chassis_target.Target_X          = 0.0f;
    chassis->Chassis_target.Target_Omega      = 0.0f;
    chassis->Chassis_target.Target_Roll       = 0.0f;
    chassis->Chassis_target.Target_Theta      = 0.0f;

    if (chassis->left_leg.theta < -0.9f || chassis->left_leg.theta > 1.4f)
    {
        chassis_control_left_leg(-4.0f);
    }
    else
    {
        chassis_control_left_leg(0.0f);
    }
    if (chassis->right_leg.theta < -0.9f || chassis->right_leg.theta > 1.4f)
    {
        chassis_control_right_leg(-4.0f);
    }
    else
    {
        chassis_control_right_leg(0.0f);
    }

}
void chassis_control_leg_pid_loop(chassis_move_t *chassis)
{
    /* ���������� */
    chassis->T_wl = 0.0f;
    chassis->T_wr = 0.0f;

    /* �ȳ�Ŀ��ֱ��ѹ����� ���� �����"����" */
    chassis->PID_legL_Position.Target = MIN_LEG_LENGTH;
    chassis->PID_legL_Position.Now    = chassis->left_leg.L0;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_legL_Position);

    chassis->PID_legR_Position.Target = MIN_LEG_LENGTH;
    chassis->PID_legR_Position.Now    = chassis->right_leg.L0;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_legR_Position);

    /* �������� */
    chassis->PID_legL_Velocity.Target = 0.0f;
    chassis->PID_legL_Velocity.Now    = chassis->left_leg.d_L0;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_legL_Velocity);

    chassis->PID_legR_Velocity.Target = 0.0f;
    chassis->PID_legR_Velocity.Now    = chassis->right_leg.d_L0;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_legR_Velocity);

    /* �Źؽڳ�ֵ���ذ� �� ������ */
    chassis->PID_tp.Target = 0.0f;
    chassis->PID_tp.Now    = chassis->theta_err;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_tp);

    chassis->PID_tp_omega.Target = chassis->PID_tp.Out;
    chassis->PID_tp_omega.Now    = chassis->d_theta_err;
    PID_TIM_Adjust_PeriodElapsedCallback(&chassis->PID_tp_omega);

    // chassis->left_leg.Tp  =  4.0f - chassis->PID_tp_omega.Out;
    // chassis->right_leg.Tp =  4.0f + chassis->PID_tp_omega.Out;
    chassis->left_leg.Tp  =  4.0f;
    chassis->right_leg.Tp =  4.0f;

    /* ���������ȳ� PID + ���ɲ������� Follow ģʽһ�£� */
    chassis->left_leg.F0  =  chassis->PID_legL_Position.Out + chassis->PID_legL_Velocity.Out- chassis->spring_force_l + 10.0f;
    chassis->right_leg.F0 = -chassis->PID_legR_Position.Out - chassis->PID_legR_Velocity.Out+ chassis->spring_force_r;

    VMC_Calc_2(&chassis->left_leg);
    VMC_Calc_2(&chassis->right_leg);
}