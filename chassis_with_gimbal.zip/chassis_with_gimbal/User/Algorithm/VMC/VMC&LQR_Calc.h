/**
  ******************************************************************************
  * @file           : VMC&LQR_Calc.h
  * @author         : gagami
  * @brief          : None
  * @attention      : None
  * @date           : 2025/8/7
  ******************************************************************************
  */
#ifndef VMC_LQR_CALC_H
#define VMC_LQR_CALC_H

/* Includes ------------------------------------------------------------------*/
#include "struct_typedef.h"
#include "INS_Task.h"
/* Define --------------------------------------------------------------------*/

/* Enum ----------------------------------------------------------------------*/

/* Variable && Struct --------------------------------------------------------*/

typedef struct
{
    const INS_t *INS_point;

    float L0, phi0; //C��ļ�����

    float d_phi0; //����C��Ƕ�phi0�ı任��
    float last_phi0; //��һ��C��Ƕȣ����ڼ���Ƕ�phi0�ı任��d_phi0

    float phi2, phi3;
    float phi1, phi4;
    float d_phi1, d_phi4;

    float torque_set[2]; //VMC����������������

    float F0;
    float Tp;
    float F02;

    float theta;
    float d_theta; //theta��һ�׵���
    float last_d_theta;
    float dd_theta; //theta�Ķ��׵���

    float d_L0; //L0��һ�׵���
    float dd_L0; //L0�Ķ��׵���
    float last_L0;
    float last_d_L0;

    float FN; //֧����
} vmc_leg_t;

/* Function Declaration ------------------------------------------------------*/
void VMC_Calc_1(vmc_leg_t *vmc, float dt);

void VMC_Calc_2(vmc_leg_t *vmc);

uint8_t ground_detection(vmc_leg_t *vmc, const INS_t *ins);

void Fitting_K_Calc(float (*fitting_k)[10], float (*p)[6], float L_l, float L_r);

/* Function ------------------------------------------------------------------*/
extern float P[40][6];

#endif //VMC_LQR_CALC_H