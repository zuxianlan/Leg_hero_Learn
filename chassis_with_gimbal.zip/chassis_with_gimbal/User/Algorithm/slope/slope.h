#ifndef SLOPE_H
#define SLOPE_H
#include "struct_typedef.h"

typedef enum
{
    Slope_First_REAL,
    // �������ܵ�ö��ֵ
} Enum_Slope_First;

typedef struct
{
    float Out;
    Enum_Slope_First Slope_First;
    float Now_Planning;
    float Now_Real;
    float Increase_Value;
    float Decrease_Value;
    float Target;
} Slope_t;

//���ٿ���
extern fp32 invSqrt(fp32 num);

//б��������ʼ��
void slope_init(Slope_t *slope, float increase_value, float decrease_value, Enum_Slope_First slope_first);

void slope_calc(Slope_t *slope);


#endif