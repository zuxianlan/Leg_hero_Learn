#include "slope.h"
#include "arm_math.h"

//���ٿ���
fp32 invSqrt(fp32 num)
{
    fp32 halfnum = 0.5f * num;
    fp32 y = num;
    long i = *(long *) &y;
    i = 0x5f3759df - (i >> 1);
    y = *(fp32 *) &i;
    y = y * (1.5f - (halfnum * y * y));
    return y;
}

void slope_init(Slope_t *slope, float increase_value, float decrease_value, Enum_Slope_First slope_first)
{
    slope->Out = 0.0f;
    slope->Slope_First = slope_first;
    slope->Now_Planning = 0.0f;
    slope->Now_Real = 0.0f;
    slope->Increase_Value = increase_value;
    slope->Decrease_Value = decrease_value;
    slope->Target = 0.0f;
}

void slope_calc(Slope_t *slope)
{
    // �滮Ϊ��ǰ��ʵֵ���ȵĶ����߼�
    if (slope->Slope_First == Slope_First_REAL)
    {
        if ((slope->Target >= slope->Now_Real && slope->Now_Real >= slope->Now_Planning) || (
                slope->Target <= slope->Now_Real && slope->Now_Real <= slope->Now_Planning))
        {
            slope->Out = slope->Now_Real;
        }
    }

    if (slope->Now_Planning > 0.0f)
    {
        if (slope->Target > slope->Now_Planning)
        {
            // ��ֵ����
            if (fabs(slope->Now_Planning - slope->Target) > slope->Increase_Value)
            {
                slope->Out += slope->Increase_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
        else if (slope->Target < slope->Now_Planning)
        {
            // ��ֵ����
            if (fabs(slope->Now_Planning - slope->Target) > slope->Decrease_Value)
            {
                slope->Out -= slope->Decrease_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
    }
    else if (slope->Now_Planning < 0.0f)
    {
        if (slope->Target < slope->Now_Planning)
        {
            // ��ֵ����
            if (fabs(slope->Now_Planning - slope->Target) > slope->Increase_Value)
            {
                slope->Out -= slope->Increase_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
        else if (slope->Target > slope->Now_Planning)
        {
            // ��ֵ����
            if (fabs(slope->Now_Planning - slope->Target) > slope->Decrease_Value)
            {
                slope->Out += slope->Decrease_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
    }
    else
    {
        if (slope->Target > slope->Now_Planning)
        {
            // 0ֵ������
            if (fabs(slope->Now_Planning - slope->Target) > slope->Increase_Value)
            {
                slope->Out += slope->Increase_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
        else if (slope->Target < slope->Now_Planning)
        {
            // 0ֵ������
            if (fabs(slope->Now_Planning - slope->Target) > slope->Increase_Value)
            {
                slope->Out -= slope->Increase_Value;
            }
            else
            {
                slope->Out = slope->Target;
            }
        }
    }

    // �ƺ���
    slope->Now_Planning = slope->Out;
}